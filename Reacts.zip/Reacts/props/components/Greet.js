import React from 'react'

const Greet = (props) => {

console.log(props)
return (
<div>
<h1>
    Hello {props.name} a.k.a {props.Anothername} 
</h1>
{props.beautiful}
</div>
)
}

export default Greet