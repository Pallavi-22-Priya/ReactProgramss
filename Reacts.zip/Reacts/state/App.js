import './App.css';
import { Component } from 'react'
import Counter from './Counter';
import Greet from './components/Greet'
import Welcome from './components/Welcome'
class  App extends Component{
  render(){
  return (
    <div className="App">

   { /*  <Counter />*/}
     {/* <Message />*/}
      <Greet  name="Brook" Anothername="Batman"/>
     {/*// <p> This is a most beautiful props </p>
      //<Greet  name="Flower" Anothername="beauty" />
      //<button>Frangance</button>
  // <Greet  name="Lion"  Anothername="King"/>*/}
    <Welcome name="Lion" Anothername="King" />
      
    </div>
  );
}
}

export default App;
