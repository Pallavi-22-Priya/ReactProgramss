import React from 'react'

  function Student({student}) {
  return (
    <div>
      <h2>
      I am {student.name}. Iam{student.age}  years old. I know {student.skill} 
      </h2>
    </div>
  )
}

export default Student