import React, { Component } from 'react'

 class Usergreet extends Component {
   constructor(props) {
     super(props)
     this.state = {
       isLoggedIn: true
   }
  }
  render() {

    return   this.state.isLoggedIn && <div> Welcome Pallavi</div>
    /*this.state.isLoggedIn ?
      (<div>Welcome Pallavi</div> ):
     ( <div> Welcome Guest</div>
    )
     
   /* let message
    if(this.state.isLoggedIn) {
      message = <div>Welcome Pallavi </div>
    }
    else {
      message = <div>Welcome Guest</div>
    }
  return <div>{ message}</div>

   /*} if(this.state.isLoggedIn)
    {
      return (
        <div> Welcome Pallavi</div>
      )
    }*/
    /*else{
      <div> Welcome Guest</div>
    }*/
   /*} return (
      <div>
        <div> Welcome Pallavi </div>
        <div> Welcome Guest</div>

      </div>
      
    )*/
   }
 }
export default Usergreet
