import './App.css';

import Usergreet from './component/Usergreet'

function App() {
  return (
    <div className="App">
      <Usergreet />
      {/*<Parentcomponent />*/}
    </div>
  );
}

export default App;
