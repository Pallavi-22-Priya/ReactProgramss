import React  from 'react'

//function Greet() {
  //  return <h1>Hello PallaviPriya</h1>
//}

const Greet = () => <h1>Hello Pallavi</h1>


export default Greet